const request = require('request');
const cheerio = require('cheerio');
const jsonfile = require('jsonfile');

request('https://cdn.adimo.co/clients/Adimo/test/index.html', function (error, response, body) {
    console.error('error:', error); // Print the error if one occurred
    
	const $ = cheerio.load(body);		//Loading the HTML body
	
	let itemObj = [];
	
	$('div.item').each(function(i, elem){
		let title = $(elem).find('h1').text();			//Getting elements from Item
		let url = $(elem).find('img').attr('src');
		let price = $(elem).find('.price').text();
		let old_price = $(elem).find('.oldPrice').text();
			
		if(price < old_price){			//If new price is lower than old price, that means a discount has occured
			itemObj.push({'title': title, 'url': url, 'price': price, 'pre_discount': old_price});
		}else{
			itemObj.push({'title': title, 'url': url, 'price': price});
		}
    });
	
	var total_price = 0;
	for (i = 0; i < itemObj.length; i++) {
		var x = itemObj[i].price.replace(/[^\d\.]/g, '');	//Removes pound(£) symbol from string so it can be parsed as float
		total_price = total_price + parseFloat(x);			//Parses string as float to do addition
	}
	
	var average_price = total_price / itemObj.length;		//Average = total of all prices / number of items
	
	let data = {									//Data to be sent to JSON
		'objects': itemObj,
		'numberOfItems': itemObj.length,
		'averagePrice': '£' + average_price
	};
	
	jsonfile.writeFile('data.json', data);			//Sending to JSON file. Data is one large line in JSON file
	
	console.log({									//Displaying in console for easier time viewing data
		'objects': itemObj,
		'numberOfItems': itemObj.length,
		'averagePrice': '£' + average_price
	});
});